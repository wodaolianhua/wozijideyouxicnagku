'use strict';

/* ===== 契约枚举（数值必须与 Contracts.ts / Enums.cs 一致） ===== */
const TerrainType = { Plain: 0, Hill: 1, Mountain: 2, Forest: 3, River: 4 };
const Faction = { Player: 0, Enemy: 1, Neutral: 2 };
const OrderKind = { MoveTo: 0, MoveVia: 1, Hold: 2 };
const ResolveResultCode = { Ok: 0, NoPath: 1, InvalidTarget: 2, AlreadyArrived: 3 };

const TERRAIN = {
  0: { name: '平原', nodeFill: '#5d8a4f', cell: '74,110,62', alpha: 0.30 },
  1: { name: '丘陵', nodeFill: '#9a8a4c', cell: '126,112,62', alpha: 0.28 },
  2: { name: '山地', nodeFill: '#8a7a6a', cell: '112,98,86', alpha: 0.32 },
  3: { name: '森林', nodeFill: '#3f7550', cell: '48,92,62', alpha: 0.32 },
  4: { name: '河流', nodeFill: '#3b86a8', cell: '44,100,132', alpha: 0.34 },
};

const UNIT_MARK = ['步', '骑', '弓', '器'];
const UNIT_NAME = ['步兵', '骑兵', '弓兵', '器械'];
const FACTION_STYLE = {
  0: { name: '我方', color: '#4b9dff', rgb: '75,157,255' },
  1: { name: '敌军', color: '#ff5f5f', rgb: '255,95,95' },
  2: { name: '中立', color: '#b8c4cf', rgb: '184,196,207' },
};
const CODE_MESSAGE = {
  1: '路网不可达：该目标无法抵达',
  2: '目标节点无效',
  3: '部队已在目标节点',
};
const TAU = Math.PI * 2;

/* ===== DOM ===== */
const canvas = document.getElementById('map');
const ctx = canvas.getContext('2d');
const timeValueEl = document.getElementById('timeValue');
const clockEl = document.getElementById('clock');
const playerStatEl = document.getElementById('playerStat');
const enemyStatEl = document.getElementById('enemyStat');
const selectedNameEl = document.getElementById('selectedName');
const selectedDetailEl = document.getElementById('selectedDetail');
const waypointListEl = document.getElementById('waypointList');
const btnOrder = document.getElementById('btnOrder');
const btnClear = document.getElementById('btnClear');
const btnStep = document.getElementById('btnStep');
const btnFastForward = document.getElementById('btnFastForward');
const btnReset = document.getElementById('btnReset');
const toastLayer = document.getElementById('toastLayer');
const modalLayer = document.getElementById('modalLayer');

/* ===== 运行时状态 ===== */
let world = null;
let selectedArmyId = null;
let waypoints = [];
let previewPath = [];
let trailHistory = new Map();
let hoverArmyId = null;
let hoverNodeId = null;
let flashes = [];
let busy = false;
let hintShown = false;
let previewSeq = 0;
let loadError = '';
let cssW = 0;
let cssH = 0;
let dpr = 1;

const layout = { scale: 1, ox: 0, oy: 0, nodes: [], armies: [], byId: new Map() };

/* ===== 画布与地形底图 ===== */
const terrainRaster = document.createElement('canvas');
const trCtx = terrainRaster.getContext('2d');
let needTerrain = true;

function resize() {
  dpr = Math.min(2, window.devicePixelRatio || 1);
  cssW = Math.max(1, canvas.clientWidth);
  cssH = Math.max(1, canvas.clientHeight);
  canvas.width = Math.round(cssW * dpr);
  canvas.height = Math.round(cssH * dpr);
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  terrainRaster.width = canvas.width;
  terrainRaster.height = canvas.height;
  trCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
  computeLayout();
  needTerrain = true;
}

function computeLayout() {
  layout.nodes = [];
  layout.armies = [];
  layout.byId = new Map();
  if (!world) return;

  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  for (const n of world.Map.Nodes) {
    if (n.X < minX) minX = n.X;
    if (n.X > maxX) maxX = n.X;
    if (n.Y < minY) minY = n.Y;
    if (n.Y > maxY) maxY = n.Y;
  }

  const padL = 44, padR = 44, padT = 92, padB = 132;
  const availW = Math.max(240, cssW - padL - padR);
  const availH = Math.max(240, cssH - padT - padB);
  const spanX = Math.max(1, maxX - minX);
  const spanY = Math.max(1, maxY - minY);
  const scale = Math.min(availW / spanX, availH / spanY);

  layout.scale = scale;
  layout.ox = padL + (availW - spanX * scale) / 2 - minX * scale;
  layout.oy = padT + (availH - spanY * scale) / 2 - minY * scale;

  layout.nodes = world.Map.Nodes.map(n => ({
    node: n,
    sx: n.X * scale + layout.ox,
    sy: n.Y * scale + layout.oy,
  }));
  layout.byId = new Map(layout.nodes.map(it => [it.node.Id, it]));

  const items = world.Armies.map(a => {
    const p = armyWorldPos(a);
    return {
      army: a,
      sx: p.x * scale + layout.ox,
      sy: p.y * scale + layout.oy,
      idle: isArmyIdle(a),
    };
  });

  const groups = new Map();
  for (const it of items) {
    if (!it.idle) continue;
    if (!groups.has(it.army.NodeId)) groups.set(it.army.NodeId, []);
    groups.get(it.army.NodeId).push(it);
  }

  for (const it of items) {
    if (!it.idle) continue;
    const group = groups.get(it.army.NodeId);
    const index = group.indexOf(it);
    if (group.length === 1) {
      it.sy -= 46;
    } else {
      const angle = -Math.PI / 2 + (index * TAU) / group.length;
      it.sx += Math.cos(angle) * 42;
      it.sy += Math.sin(angle) * 42 - 16;
    }
  }

  layout.armies = items;
}

function w2s(x, y) {
  return [x * layout.scale + layout.ox, y * layout.scale + layout.oy];
}

function nodeWorld(id) {
  const n = world && world.Map.Nodes.find(item => item.Id === id);
  return n ? { x: n.X, y: n.Y } : { x: 0, y: 0 };
}

function armyWorldPos(army) {
  const path = army.PlannedPath || [];
  const index = Math.max(0, Math.min(army.PathIndex | 0, path.length - 1));
  if (path.length === 0) return nodeWorld(army.NodeId);
  if (index + 1 >= path.length) return nodeWorld(path[index]);
  const from = nodeWorld(path[index]);
  const to = nodeWorld(path[index + 1]);
  const p = Math.max(0, Math.min(1, army.EdgeProgress || 0));
  return { x: from.x + (to.x - from.x) * p, y: from.y + (to.y - from.y) * p };
}

function isArmyIdle(army) {
  const path = army.PlannedPath || [];
  return path.length === 0 || army.PathIndex + 1 >= path.length;
}

/* ===== 地形底图（Voronoi 色块，静态缓存） ===== */
function renderTerrainRaster() {
  trCtx.clearRect(0, 0, cssW, cssH);

  const base = trCtx.createRadialGradient(cssW * 0.5, cssH * 0.42, 60, cssW * 0.5, cssH * 0.5, Math.max(cssW, cssH) * 0.9);
  base.addColorStop(0, '#0f1922');
  base.addColorStop(0.62, '#0a1118');
  base.addColorStop(1, '#05090d');
  trCtx.fillStyle = base;
  trCtx.fillRect(0, 0, cssW, cssH);

  const nodes = layout.nodes;
  if (!nodes.length) return;

  // 世界网格
  const startX = Math.floor((0 - layout.ox) / layout.scale / 50) * 50;
  const endX = Math.ceil((cssW - layout.ox) / layout.scale / 50) * 50;
  const startY = Math.floor((0 - layout.oy) / layout.scale / 50) * 50;
  const endY = Math.ceil((cssH - layout.oy) / layout.scale / 50) * 50;
  trCtx.strokeStyle = 'rgba(110,160,200,0.055)';
  trCtx.lineWidth = 1;
  trCtx.beginPath();
  for (let gx = startX; gx <= endX; gx += 50) {
    const sx = gx * layout.scale + layout.ox;
    trCtx.moveTo(sx, 0);
    trCtx.lineTo(sx, cssH);
  }
  for (let gy = startY; gy <= endY; gy += 50) {
    const sy = gy * layout.scale + layout.oy;
    trCtx.moveTo(0, sy);
    trCtx.lineTo(cssW, sy);
  }
  trCtx.stroke();

  // Voronoi：每个格子归属最近的节点，按节点地形上色
  const CELL = 12;
  for (let y = 0; y < cssH; y += CELL) {
    for (let x = 0; x < cssW; x += CELL) {
      const px = x + CELL / 2;
      const py = y + CELL / 2;
      let best = null;
      let bestDist = Infinity;
      for (const item of nodes) {
        const dx = item.sx - px;
        const dy = item.sy - py;
        const dist = dx * dx + dy * dy;
        if (dist < bestDist) {
          bestDist = dist;
          best = item;
        }
      }
      if (!best) continue;
      const terrain = TERRAIN[best.node.Terrain] || TERRAIN[0];
      const checker = ((x / CELL + y / CELL) | 0) % 3 === 0 ? 0.82 : 1;
      trCtx.fillStyle = `rgba(${terrain.cell},${(terrain.alpha * 0.58 * checker).toFixed(3)})`;
      trCtx.fillRect(x, y, CELL + 0.6, CELL + 0.6);
    }
  }

  const vignette = trCtx.createRadialGradient(
    cssW / 2, cssH / 2, Math.min(cssW, cssH) * 0.34,
    cssW / 2, cssH / 2, Math.max(cssW, cssH) * 0.78);
  vignette.addColorStop(0, 'rgba(0,0,0,0)');
  vignette.addColorStop(1, 'rgba(0,0,0,0.55)');
  trCtx.fillStyle = vignette;
  trCtx.fillRect(0, 0, cssW, cssH);
}

/* ===== 绘制 ===== */
function draw(now) {
  ctx.clearRect(0, 0, cssW, cssH);

  if (!world) {
    const message = loadError || '载入战场…';
    ctx.fillStyle = '#070b10';
    ctx.fillRect(0, 0, cssW, cssH);
    ctx.fillStyle = 'rgba(160,190,215,0.8)';
    ctx.font = '14px "Microsoft YaHei", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(message, cssW / 2, cssH / 2);
    return;
  }

  if (needTerrain) {
    renderTerrainRaster();
    needTerrain = false;
  }
  ctx.drawImage(terrainRaster, 0, 0, cssW, cssH);

  drawEdges();
  drawPlannedPaths();
  drawTrails();
  drawPreview(now);
  drawNodes();
  drawArmies(now);
  drawFlashes(now);
  drawHoverTooltip();
}

function drawEdges() {
  for (const edge of world.Map.Edges) {
    const a = layout.byId.get(edge.From);
    const b = layout.byId.get(edge.To);
    if (!a || !b) continue;

    ctx.save();
    ctx.lineCap = 'round';

    // 暗色压边，保证在色块上也看得清
    ctx.beginPath();
    ctx.moveTo(a.sx, a.sy);
    ctx.lineTo(b.sx, b.sy);
    ctx.strokeStyle = 'rgba(4,8,11,0.6)';
    ctx.lineWidth = 6;
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(a.sx, a.sy);
    ctx.lineTo(b.sx, b.sy);
    if (edge.Type === 1) {
      ctx.setLineDash([9, 7]);
      ctx.strokeStyle = 'rgba(180,138,94,0.62)';
      ctx.lineWidth = 2.4;
    } else {
      ctx.strokeStyle = 'rgba(198,170,110,0.55)';
      ctx.lineWidth = 3.4;
    }
    ctx.stroke();

    if (edge.Type === 0) {
      ctx.beginPath();
      ctx.moveTo(a.sx, a.sy);
      ctx.lineTo(b.sx, b.sy);
      ctx.setLineDash([]);
      ctx.strokeStyle = 'rgba(245,222,166,0.28)';
      ctx.lineWidth = 1.1;
      ctx.stroke();
    }
    ctx.restore();
  }
}

function drawPlannedPaths() {
  for (const army of world.Armies) {
    const path = army.PlannedPath || [];
    const index = Math.max(0, Math.min(army.PathIndex | 0, path.length - 1));
    if (path.length < 2 || index + 1 >= path.length) continue;

    const style = FACTION_STYLE[army.Faction] || FACTION_STYLE[2];
    const selected = army.Id === selectedArmyId;
    const start = armyWorldPos(army);
    const points = [w2s(start.x, start.y)];
    for (let i = index + 1; i < path.length; i++) {
      const n = layout.byId.get(path[i]);
      if (n) points.push([n.sx, n.sy]);
    }
    if (points.length < 2) continue;

    ctx.save();
    ctx.setLineDash([5, 5]);
    ctx.lineWidth = selected ? 1.9 : 1.4;
    ctx.strokeStyle = `rgba(${style.rgb},${selected ? 0.5 : 0.22})`;
    ctx.beginPath();
    points.forEach((p, i) => (i === 0 ? ctx.moveTo(p[0], p[1]) : ctx.lineTo(p[0], p[1])));
    ctx.stroke();
    ctx.restore();
  }
}

function drawTrails() {
  for (const [armyId, points] of trailHistory) {
    if (points.length < 2) continue;
    const army = getArmy(armyId);
    const style = FACTION_STYLE[army ? army.Faction : 0];
    const screen = points.map(p => w2s(p.X, p.Y));

    ctx.save();
    ctx.lineJoin = 'round';
    ctx.lineCap = 'round';
    ctx.strokeStyle = `rgba(${style.rgb},0.55)`;
    ctx.lineWidth = 2.2;
    ctx.beginPath();
    screen.forEach((p, i) => (i === 0 ? ctx.moveTo(p[0], p[1]) : ctx.lineTo(p[0], p[1])));
    ctx.stroke();
    ctx.restore();

    drawChevrons(screen, `rgba(${style.rgb},0.85)`, 5.5, 74);
  }
}

function drawChevrons(points, color, size, spacing) {
  ctx.save();
  ctx.strokeStyle = color;
  ctx.lineWidth = 1.8;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';

  let acc = spacing * 0.5;
  for (let i = 1; i < points.length; i++) {
    const x0 = points[i - 1][0], y0 = points[i - 1][1];
    const x1 = points[i][0], y1 = points[i][1];
    const dx = x1 - x0, dy = y1 - y0;
    const len = Math.hypot(dx, dy);
    if (len < 0.001) continue;
    const ux = dx / len, uy = dy / len;

    while (acc <= len) {
      const px = x0 + ux * acc;
      const py = y0 + uy * acc;
      ctx.beginPath();
      ctx.moveTo(px - ux * size - uy * size * 0.85, py - uy * size + ux * size * 0.85);
      ctx.lineTo(px, py);
      ctx.lineTo(px - ux * size + uy * size * 0.85, py - uy * size - ux * size * 0.85);
      ctx.stroke();
      acc += spacing;
    }
    acc -= len;
  }
  ctx.restore();
}

function drawPreview(now) {
  if (!selectedArmyId) return;

  if (previewPath.length >= 2) {
    const points = previewPath.map(id => layout.byId.get(id)).filter(Boolean).map(n => [n.sx, n.sy]);
    if (points.length >= 2) {
      ctx.save();
      ctx.setLineDash([10, 7]);
      ctx.lineDashOffset = -(now / 55) % 17;
      ctx.strokeStyle = 'rgba(120,230,255,0.9)';
      ctx.lineWidth = 2.6;
      ctx.lineJoin = 'round';
      ctx.shadowColor = 'rgba(87,212,255,0.55)';
      ctx.shadowBlur = 10;
      ctx.beginPath();
      points.forEach((p, i) => (i === 0 ? ctx.moveTo(p[0], p[1]) : ctx.lineTo(p[0], p[1])));
      ctx.stroke();
      ctx.restore();
    }
  }

  waypoints.forEach((id, i) => {
    const item = layout.byId.get(id);
    if (!item) return;
    ctx.save();
    ctx.beginPath();
    ctx.arc(item.sx, item.sy, 10, 0, TAU);
    ctx.fillStyle = 'rgba(8,34,45,0.95)';
    ctx.fill();
    ctx.lineWidth = 1.6;
    ctx.strokeStyle = 'rgba(120,230,255,0.9)';
    ctx.stroke();
    ctx.fillStyle = '#bff2ff';
    ctx.font = '700 11px "Microsoft YaHei", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(String(i + 1), item.sx, item.sy + 0.5);
    ctx.restore();
  });
}

function drawNodes() {
  for (const item of layout.nodes) {
    const node = item.node;
    const terrain = TERRAIN[node.Terrain] || TERRAIN[0];
    const hovered = hoverNodeId === node.Id;

    if (hovered) {
      ctx.beginPath();
      ctx.arc(item.sx, item.sy, 20, 0, TAU);
      ctx.strokeStyle = 'rgba(120,230,255,0.35)';
      ctx.lineWidth = 2;
      ctx.stroke();
    }

    ctx.beginPath();
    ctx.arc(item.sx, item.sy, 12.5, 0, TAU);
    ctx.fillStyle = 'rgba(6,12,17,0.9)';
    ctx.fill();
    ctx.lineWidth = 1.6;
    ctx.strokeStyle = hovered ? 'rgba(160,235,255,0.95)' : 'rgba(190,215,235,0.45)';
    ctx.stroke();

    ctx.beginPath();
    ctx.arc(item.sx, item.sy, 7.5, 0, TAU);
    ctx.fillStyle = terrain.nodeFill;
    ctx.fill();

    ctx.fillStyle = hovered ? '#eaf8ff' : 'rgba(206,224,240,0.78)';
    ctx.font = '12px "Microsoft YaHei", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'top';
    ctx.fillText(node.Name, item.sx, item.sy + 16);
  }
}

function drawArmies(now) {
  for (const item of layout.armies) {
    const army = item.army;
    const style = FACTION_STYLE[army.Faction] || FACTION_STYLE[2];
    const selected = army.Id === selectedArmyId;
    const hovered = army.Id === hoverArmyId;

    if (selected) {
      const k = 0.5 + 0.5 * Math.sin(now / 280);
      ctx.beginPath();
      ctx.arc(item.sx, item.sy, 20 + k * 4, 0, TAU);
      ctx.strokeStyle = `rgba(${style.rgb},${0.5 + k * 0.4})`;
      ctx.lineWidth = 2;
      ctx.stroke();

      ctx.save();
      ctx.beginPath();
      ctx.arc(item.sx, item.sy, 27, -now / 900, -now / 900 + TAU * 0.72);
      ctx.setLineDash([4, 6]);
      ctx.strokeStyle = `rgba(${style.rgb},0.6)`;
      ctx.lineWidth = 1.4;
      ctx.stroke();
      ctx.restore();
    } else if (hovered) {
      ctx.beginPath();
      ctx.arc(item.sx, item.sy, 20, 0, TAU);
      ctx.strokeStyle = 'rgba(255,255,255,0.55)';
      ctx.lineWidth = 1.5;
      ctx.stroke();
    }

    ctx.save();
    ctx.shadowColor = `rgba(${style.rgb},0.7)`;
    ctx.shadowBlur = selected ? 20 : 11;
    ctx.beginPath();
    ctx.arc(item.sx, item.sy, 15, 0, TAU);
    ctx.fillStyle = style.color;
    ctx.fill();
    ctx.restore();

    ctx.beginPath();
    ctx.arc(item.sx, item.sy, 15, 0, TAU);
    ctx.lineWidth = 1.6;
    ctx.strokeStyle = 'rgba(255,255,255,0.85)';
    ctx.stroke();

    ctx.fillStyle = '#ffffff';
    ctx.font = '700 12px "Microsoft YaHei", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(UNIT_MARK[army.UnitType] || '?', item.sx, item.sy + 0.5);

    ctx.fillStyle = style.color;
    ctx.font = '700 11px "Microsoft YaHei", sans-serif';
    ctx.textBaseline = 'top';
    ctx.fillText(String(army.Strength), item.sx, item.sy + 18);
  }
}

function drawFlashes(now) {
  flashes = flashes.filter(f => now - f.t0 < 700);
  for (const f of flashes) {
    const k = (now - f.t0) / 700;
    ctx.save();

    if (f.fromX != null) {
      ctx.beginPath();
      ctx.setLineDash([4, 4]);
      ctx.moveTo(f.fromX, f.fromY);
      ctx.lineTo(f.sx, f.sy);
      ctx.strokeStyle = `rgba(120,230,255,${0.55 * (1 - k)})`;
      ctx.lineWidth = 1.4;
      ctx.stroke();
    }

    ctx.beginPath();
    ctx.arc(f.sx, f.sy, 13 + k * 26, 0, TAU);
    ctx.setLineDash([]);
    ctx.strokeStyle = `rgba(120,230,255,${0.9 * (1 - k)})`;
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.restore();
  }
}

function drawHoverTooltip() {
  if (!hoverArmyId) return;
  const item = layout.armies.find(it => it.army.Id === hoverArmyId);
  if (!item) return;
  const army = item.army;
  const style = FACTION_STYLE[army.Faction] || FACTION_STYLE[2];
  const text = `${army.Name} · ${UNIT_NAME[army.UnitType]} · ${army.Strength} 兵`;

  ctx.save();
  ctx.font = '12px "Microsoft YaHei", sans-serif';
  const width = ctx.measureText(text).width + 20;
  const height = 26;
  let x = item.sx - width / 2;
  let y = item.sy - 44;
  x = Math.max(8, Math.min(cssW - width - 8, x));
  y = Math.max(70, y);

  ctx.beginPath();
  roundedRect(ctx, x, y, width, height, 7);
  ctx.fillStyle = 'rgba(10,18,26,0.95)';
  ctx.fill();
  ctx.strokeStyle = `rgba(${style.rgb},0.6)`;
  ctx.lineWidth = 1;
  ctx.stroke();

  ctx.fillStyle = '#eaf5ff';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(text, x + width / 2, y + height / 2 + 0.5);
  ctx.restore();
}

function roundedRect(context, x, y, w, h, r) {
  context.moveTo(x + r, y);
  context.arcTo(x + w, y, x + w, y + h, r);
  context.arcTo(x + w, y + h, x, y + h, r);
  context.arcTo(x, y + h, x, y, r);
  context.arcTo(x, y, x + w, y, r);
  context.closePath();
}

/* ===== 数据访问 ===== */
async function api(path, body) {
  const options = { cache: 'no-store' };
  if (body !== undefined) {
    options.method = 'POST';
    options.headers = { 'Content-Type': 'application/json' };
    options.body = JSON.stringify(body);
  }
  const res = await fetch(path, options);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return await res.json();
}

function getArmy(id) {
  return world ? world.Armies.find(a => a.Id === id) : null;
}

function nodeName(id) {
  const n = world && world.Map.Nodes.find(item => item.Id === id);
  return n ? n.Name : id;
}

function nodeTerrainName(id) {
  const n = world && world.Map.Nodes.find(item => item.Id === id);
  return n ? (TERRAIN[n.Terrain] || TERRAIN[0]).name : '';
}

function positionText(army) {
  const path = army.PlannedPath || [];
  const index = Math.max(0, Math.min(army.PathIndex | 0, path.length - 1));
  if (path.length === 0 || index + 1 >= path.length) {
    return `位于 ${nodeName(army.NodeId)}`;
  }
  const p = Math.round(Math.max(0, Math.min(1, army.EdgeProgress || 0)) * 100);
  return `行军中：${nodeName(path[index])} → ${nodeName(path[index + 1])}（${p}%）`;
}

/* ===== 交互 ===== */
function toLocal(ev) {
  const rect = canvas.getBoundingClientRect();
  return { x: ev.clientX - rect.left, y: ev.clientY - rect.top };
}

function pickArmy(x, y) {
  let best = null;
  let bestDist = 24;
  for (const item of layout.armies) {
    const dist = Math.hypot(item.sx - x, item.sy - y);
    if (dist <= bestDist) {
      bestDist = dist;
      best = item;
    }
  }
  return best;
}

function pickNode(x, y, threshold) {
  let best = null;
  let bestDist = threshold;
  for (const item of layout.nodes) {
    const dist = Math.hypot(item.sx - x, item.sy - y);
    if (dist <= bestDist) {
      bestDist = dist;
      best = item;
    }
  }
  return best;
}

function nearestNode(x, y) {
  let best = null;
  let bestDist = Infinity;
  for (const item of layout.nodes) {
    const dist = Math.hypot(item.sx - x, item.sy - y);
    if (dist < bestDist) {
      bestDist = dist;
      best = item;
    }
  }
  return best;
}

function flashNode(nodeItem, from) {
  flashes.push({
    sx: nodeItem.sx,
    sy: nodeItem.sy,
    fromX: from ? from.x : null,
    fromY: from ? from.y : null,
    t0: performance.now(),
  });
}

function onArmyClick(army) {
  if (army.Faction !== Faction.Player) {
    toast(`${army.Name} · ${UNIT_NAME[army.UnitType]} · ${army.Strength} 兵 · ${positionText(army)}`);
    return;
  }
  if (selectedArmyId === army.Id) {
    deselect();
    return;
  }
  selectedArmyId = army.Id;
  waypoints = [];
  previewPath = [];
  previewSeq++;
  hintShown = true;
  updateUI();
}

function onNodeClick(nodeItem, from) {
  flashNode(nodeItem, from);
  if (!selectedArmyId) {
    if (!hintShown) {
      hintShown = true;
      toast('先点选蓝色我方部队，再点地图节点下令', 'warn');
    }
    return;
  }
  addWaypoint(nodeItem.node.Id);
}

function addWaypoint(nodeId) {
  const army = getArmy(selectedArmyId);
  if (!army) {
    deselect();
    return;
  }
  if (waypoints.length && waypoints[waypoints.length - 1] === nodeId) {
    toast('路径末尾已经是该节点', 'warn');
    return;
  }
  if (!waypoints.length && nodeId === army.NodeId) {
    toast('该部队已在此节点，请点其他节点', 'warn');
    return;
  }
  waypoints.push(nodeId);
  refreshPreview();
}

async function refreshPreview() {
  if (!selectedArmyId || waypoints.length === 0) {
    previewPath = [];
    updateUI();
    return;
  }
  const seq = ++previewSeq;
  try {
    const res = await api('/api/preview', { ArmyId: selectedArmyId, Waypoints: waypoints.slice() });
    if (seq !== previewSeq) return;
    if (res.Code === ResolveResultCode.Ok && res.Path && res.Path.length > 0) {
      previewPath = res.Path;
    } else {
      previewPath = [];
      toast(CODE_MESSAGE[res.Code] || '该路线不可通行', 'warn');
      waypoints.pop();
      if (waypoints.length) {
        refreshPreview();
        return;
      }
    }
  } catch (err) {
    if (seq === previewSeq) {
      previewPath = [];
      toast(`路径预览失败：${err.message}`, 'bad');
    }
  }
  updateUI();
}

function undoWaypoint() {
  if (!waypoints.length) return;
  waypoints.pop();
  refreshPreview();
}

function clearWaypoints() {
  waypoints = [];
  previewPath = [];
  previewSeq++;
  updateUI();
}

function deselect() {
  selectedArmyId = null;
  clearWaypoints();
  updateUI();
}

function removeWaypointAt(index) {
  waypoints.splice(index, 1);
  refreshPreview();
}

/* ===== 请求动作 ===== */
async function issueOrder() {
  if (busy || !selectedArmyId || waypoints.length === 0) return;
  const army = getArmy(selectedArmyId);
  if (!army) return;

  const kind = waypoints.length > 1 ? OrderKind.MoveVia : OrderKind.MoveTo;
  const order = { ArmyId: selectedArmyId, Kind: kind, Waypoints: waypoints.slice() };
  const routeText = waypoints.map(id => nodeName(id)).join(' → ');

  busy = true;
  updateUI();
  try {
    const res = await api('/api/advance', { Orders: [order], Steps: 1 });
    if (res.Code === ResolveResultCode.Ok) {
      waypoints = [];
      previewPath = [];
    }
    handleResult(res);
    if (res.Code === ResolveResultCode.Ok) {
      if (!res.Encounters.length) {
        toast(`${army.Name} 已出发：${routeText}`);
      }
    } else {
      toast(CODE_MESSAGE[res.Code] || '下令失败', 'bad');
      if (res.Code === ResolveResultCode.NoPath || res.Code === ResolveResultCode.InvalidTarget) {
        previewPath = [];
      }
    }
  } catch (err) {
    toast(`下令失败：${err.message}`, 'bad');
  } finally {
    busy = false;
    updateUI();
  }
}

async function advanceStep() {
  if (busy || !world) return;
  const before = world.Time;
  busy = true;
  updateUI();
  try {
    const res = await api('/api/advance', { Orders: [], Steps: 1 });
    handleResult(res);
    if (!res.Encounters.length) {
      toast(res.State.Time > before
        ? `推进至时间步 ${res.State.Time}`
        : '所有部队已抵达或待命，时间未推进');
    }
  } catch (err) {
    toast(`推进失败：${err.message}`, 'bad');
  } finally {
    busy = false;
    updateUI();
  }
}

async function fastForward() {
  if (busy || !world) return;
  const before = world.Time;
  busy = true;
  updateUI();
  try {
    const res = await api('/api/fastforward', { Orders: [], MaxSteps: 200 });
    handleResult(res);
    if (!res.Encounters.length) {
      toast(res.State.Time > before
        ? `未遇敌，快进至时间步 ${res.State.Time}`
        : '所有部队已抵达或待命，时间未推进');
    }
  } catch (err) {
    toast(`快进失败：${err.message}`, 'bad');
  } finally {
    busy = false;
    updateUI();
  }
}

function handleResult(res) {
  world = res.State;
  appendTrails(res.Trails || []);
  computeLayout();
  previewPath = [];
  updateUI();
  flashClock();
  if (res.Encounters && res.Encounters.length) {
    showEncounterModal(res);
  }
}

function appendTrails(trails) {
  for (const trail of trails) {
    const points = trail.Points || [];
    if (!points.length) continue;

    let list = trailHistory.get(trail.ArmyId);
    if (!list) {
      list = [];
      trailHistory.set(trail.ArmyId, list);
    }

    for (const p of points) {
      const last = list[list.length - 1];
      if (last && Math.abs(last.X - p.X) < 1e-6 && Math.abs(last.Y - p.Y) < 1e-6) continue;
      list.push({ X: p.X, Y: p.Y, Time: p.Time });
    }
  }
}

function flashClock() {
  clockEl.classList.add('flash');
  setTimeout(() => clockEl.classList.remove('flash'), 420);
}

/* ===== UI ===== */
function updateUI() {
  timeValueEl.textContent = world ? String(world.Time) : '—';

  if (world) {
    const players = world.Armies.filter(a => a.Faction === Faction.Player);
    const enemies = world.Armies.filter(a => a.Faction === Faction.Enemy);
    const playerTotal = players.reduce((sum, a) => sum + a.Strength, 0);
    const enemyTotal = enemies.reduce((sum, a) => sum + a.Strength, 0);
    playerStatEl.textContent = `${players.length} 支 · ${playerTotal} 兵`;
    enemyStatEl.textContent = `${enemies.length} 支 · ${enemyTotal} 兵`;
  }

  const army = getArmy(selectedArmyId);
  if (!army) {
    selectedArmyId = null;
    selectedNameEl.textContent = '未选中部队';
    selectedDetailEl.textContent = '点选蓝色部队后，点击地图节点下令';
  } else {
    selectedNameEl.textContent = `${army.Name} · ${UNIT_NAME[army.UnitType]} · ${army.Strength} 兵`;
    selectedDetailEl.textContent = positionText(army);
  }

  renderWaypoints();

  btnOrder.disabled = busy || !army || waypoints.length === 0;
  btnClear.disabled = busy || waypoints.length === 0;
  btnStep.disabled = busy || !world;
  btnFastForward.disabled = busy || !world;
  btnReset.disabled = busy || !world;

  if (army) {
    const lastNode = waypoints.length ? nodeName(waypoints[waypoints.length - 1]) : null;
    const label = waypoints.length > 1 ? `下令行军（${waypoints.length} 点折线）`
      : waypoints.length === 1 ? `下令行军（前往${lastNode}）` : '下令行军';
    btnOrder.textContent = label;
  } else {
    btnOrder.textContent = '下令行军';
  }
}

function renderWaypoints() {
  waypointListEl.innerHTML = '';
  waypoints.forEach((id, index) => {
    if (index > 0) {
      const arrow = document.createElement('span');
      arrow.className = 'wp-arrow';
      arrow.textContent = '›';
      waypointListEl.appendChild(arrow);
    }
    const chip = document.createElement('button');
    chip.type = 'button';
    chip.className = 'wp-chip';
    chip.title = '点击移除该目标点';
    const badge = document.createElement('span');
    badge.className = 'idx';
    badge.textContent = String(index + 1);
    const label = document.createElement('span');
    label.textContent = `${nodeName(id)}·${nodeTerrainName(id)}`;
    chip.append(badge, label);
    chip.addEventListener('click', () => removeWaypointAt(index));
    waypointListEl.appendChild(chip);
  });
}

function toast(message, tone, duration) {
  const el = document.createElement('div');
  el.className = `toast${tone ? ` ${tone}` : ''}`;
  el.textContent = message;
  toastLayer.appendChild(el);
  requestAnimationFrame(() => el.classList.add('show'));
  const life = duration || 2600;
  setTimeout(() => {
    el.classList.remove('show');
    setTimeout(() => el.remove(), 260);
  }, life);
}

/* ===== 模态框 ===== */
function showModal({ title, subtitle, html, actions }) {
  modalLayer.innerHTML = '';

  const backdrop = document.createElement('div');
  backdrop.className = 'modal-backdrop';

  const modal = document.createElement('div');
  modal.className = 'modal';
  modal.setAttribute('role', 'dialog');
  modal.setAttribute('aria-modal', 'true');

  const head = document.createElement('div');
  head.className = 'modal-head';
  const titleEl = document.createElement('div');
  titleEl.className = 'modal-title';
  titleEl.textContent = title;
  head.appendChild(titleEl);
  if (subtitle) {
    const subEl = document.createElement('div');
    subEl.className = 'modal-sub';
    subEl.textContent = subtitle;
    head.appendChild(subEl);
  }

  const body = document.createElement('div');
  body.className = 'modal-body';
  body.innerHTML = html;

  const actionBar = document.createElement('div');
  actionBar.className = 'modal-actions';

  (actions || []).forEach(action => {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'btn';
    if (action.primary) button.classList.add('primary');
    if (action.danger) button.classList.add('danger');
    button.textContent = action.label;
    button.addEventListener('click', () => {
      closeModal();
      if (action.onClick) action.onClick();
    });
    actionBar.appendChild(button);
  });

  backdrop.addEventListener('click', closeModal);
  modal.append(head, body, actionBar);
  modalLayer.append(backdrop, modal);
  modalLayer.classList.remove('hidden');
}

function closeModal() {
  modalLayer.classList.add('hidden');
  modalLayer.innerHTML = '';
}

function escapeHtml(text) {
  return String(text)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function showEncounterModal(res) {
  const armies = new Map(res.State.Armies.map(a => [a.Id, a]));
  const nodeNameOf = id => {
    const node = res.State.Map.Nodes.find(n => n.Id === id);
    return node ? `${node.Name}（${(TERRAIN[node.Terrain] || TERRAIN[0]).name}）` : id;
  };

  const cards = res.Encounters.map(enc => {
    const ids = enc.ArmyIds || [];
    const players = ids.map(id => armies.get(id)).filter(a => a && a.Faction === Faction.Player);
    const enemies = ids.map(id => armies.get(id)).filter(a => a && a.Faction === Faction.Enemy);
    const lossByArmy = (enc.Loss && enc.Loss.LossByArmy) || {};

    const row = army => {
      const loss = lossByArmy[army.Id] || 0;
      return `<div class="loss-row">
        <span>${escapeHtml(army.Name)}<em>${UNIT_NAME[army.UnitType]}</em></span>
        <b class="loss">-${loss}</b>
        <span class="remain">余 ${army.Strength}</span>
      </div>`;
    };

    const ambusher = armies.get(enc.AmbusherId);
    const ambushLabel = enc.IsAmbush
      ? (ambusher && ambusher.Faction === Faction.Enemy ? '敌军伏击我方' : '我方伏击敌军')
      : '正面遭遇';

    const enemyLines = enemies.map(a =>
      `${escapeHtml(a.Name)} · ${UNIT_NAME[a.UnitType]} · ${a.Strength} 兵 · ${positionText(a)}`).join('<br>');

    return `<div class="encounter-card">
      <div class="enc-head">
        <span class="enc-place">${escapeHtml(nodeNameOf(enc.NodeId))}</span>
        <span class="enc-badge ${enc.IsAmbush ? '' : 'normal'}">${ambushLabel}</span>
        <span class="enc-time">时间步 ${enc.Time}</span>
      </div>
      <div class="enc-grid">
        <div>
          <div class="enc-col-title player">我方损失</div>
          ${players.map(row).join('') || '<div class="muted">无我方部队</div>'}
        </div>
        <div>
          <div class="enc-col-title enemy">敌方损失</div>
          ${enemies.map(row).join('') || '<div class="muted">无敌军部队</div>'}
        </div>
      </div>
      <div class="enc-enemy-list">敌军位置 / 规模：<br>${enemyLines || '—'}</div>
      <div class="enc-note">损失数字来自算法结算（EncounterEvent.Loss.LossByArmy）。关闭战报后由你重新点选部队、重新下令决定撤、绕还是顶。</div>
    </div>`;
  }).join('');

  showModal({
    title: `遭遇战报 · 时间步 ${res.State.Time}`,
    subtitle: res.Encounters.length > 1
      ? `本步触发 ${res.Encounters.length} 场遭遇，时间已停在事发点`
      : '时间已停在事发点',
    html: cards,
    actions: [{ label: '知道了，关闭战报', primary: true }],
  });
}

function confirmReset() {
  if (busy) return;
  showModal({
    title: '重开本局',
    subtitle: '世界回到初始状态：18 节点 / 29 条边 / 9 支部队',
    html: '<div class="confirm-text">当前时间步与所有行军轨迹都会清空，兵力恢复初始值。<div class="muted">地图与兵力将从 01_地图数据 的 JSON 重新读取。</div></div>',
    actions: [
      { label: '取消' },
      { label: '确认重开', primary: true, onClick: doReset },
    ],
  });
}

async function doReset() {
  busy = true;
  updateUI();
  try {
    const fresh = await api('/api/reset', {});
    world = fresh;
    trailHistory = new Map();
    selectedArmyId = null;
    waypoints = [];
    previewPath = [];
    previewSeq++;
    flashes = [];
    computeLayout();
    needTerrain = true;
    updateUI();
    toast('已回到初始状态');
  } catch (err) {
    toast(`重开失败：${err.message}`, 'bad');
  } finally {
    busy = false;
    updateUI();
  }
}

/* ===== 事件绑定 ===== */
canvas.addEventListener('pointermove', ev => {
  const { x, y } = toLocal(ev);
  const army = pickArmy(x, y);
  hoverArmyId = army ? army.army.Id : null;
  const node = army ? null : pickNode(x, y, 26);
  hoverNodeId = node ? node.node.Id : null;
  canvas.style.cursor = army || node ? 'pointer' : 'crosshair';
});

canvas.addEventListener('pointerleave', () => {
  hoverArmyId = null;
  hoverNodeId = null;
});

canvas.addEventListener('click', ev => {
  if (ev.button !== 0) return;
  const local = toLocal(ev);
  const army = pickArmy(local.x, local.y);
  if (army) {
    onArmyClick(army.army);
    return;
  }
  const node = nearestNode(local.x, local.y);
  if (node) onNodeClick(node, local);
});

canvas.addEventListener('contextmenu', ev => {
  ev.preventDefault();
  undoWaypoint();
});

btnOrder.addEventListener('click', issueOrder);
btnClear.addEventListener('click', clearWaypoints);
btnStep.addEventListener('click', advanceStep);
btnFastForward.addEventListener('click', fastForward);
btnReset.addEventListener('click', confirmReset);

window.addEventListener('keydown', ev => {
  if (!modalLayer.classList.contains('hidden')) {
    if (ev.key === 'Escape') {
      ev.preventDefault();
      closeModal();
    }
    return;
  }
  if (ev.key === 'Enter') {
    ev.preventDefault();
    issueOrder();
  } else if (ev.key === 'Escape') {
    if (waypoints.length) clearWaypoints();
    else if (selectedArmyId) deselect();
  } else if (ev.key === 'Backspace') {
    if (waypoints.length) {
      ev.preventDefault();
      undoWaypoint();
    }
  }
});

window.addEventListener('resize', resize);

/* ===== 启动 ===== */
function tick(now) {
  draw(now);
  requestAnimationFrame(tick);
}

async function boot() {
  resize();
  requestAnimationFrame(tick);
  try {
    world = await api('/api/world');
    computeLayout();
    needTerrain = true;
    updateUI();
  } catch (err) {
    loadError = `无法载入世界数据（${err.message}），请确认后端 /api/world`;
    toast(loadError, 'bad', 8000);
  }
}

boot();
